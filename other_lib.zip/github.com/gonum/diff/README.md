# Gonum diff  [![Build Status](https://travis-ci.org/gonum/diff.svg)](https://travis-ci.org/gonum/diff)  [![Coverage Status](https://img.shields.io/coveralls/gonum/diff.svg)](https://coveralls.io/r/gonum/diff)

This is a package for computing derivatives of functions for the Go language.

## Issues

If you find any bugs, feel free to file an issue on the github issue tracker. Discussions on API changes, added features, code review, or similar requests are preferred on the gonum-dev Google Group.

https://groups.google.com/forum/#!forum/gonum-dev

## License

Please see github.com/gonum/license for general license information, contributors, authors, etc on the Gonum suite of packages.

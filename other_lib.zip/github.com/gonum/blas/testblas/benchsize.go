package testblas

const (
	SmallMat  = 10
	MediumMat = 100
	LargeMat  = 1000
	HugeMat   = 10000
)

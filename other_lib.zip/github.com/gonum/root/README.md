general
=======
Package root provides algorithms to calculate the zero value of a function.
This package is in development, so use at your own risk. API is still likely to change.

package root

var (
	max_Iter int
	tol      float64
)

func init() {
	max_Iter = 100
	tol = 0.001
}

general
=======
Package general provides general purpose functions and data structures for the other gonum packages.
This package is in development, so use at your own risk. API is still likely to change.

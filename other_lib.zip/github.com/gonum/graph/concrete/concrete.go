// Copyright ©2014 The gonum Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package concrete

// TODO(anyone) Package level documentation for this describing the overall
// reason for the package and a summary for the provided types.

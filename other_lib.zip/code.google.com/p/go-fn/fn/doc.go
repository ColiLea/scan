// Copyright 2012 - 2013 The Fn Authors. All rights reserved. See the LICENSE file.

// Special math functions not included in "math" package.
package fn

